<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class FilterDescription extends Model
{
    use HasFactory;
    protected $table='oc_filter_description';
    protected $primaryKey='filter_id';
}
