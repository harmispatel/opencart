<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class FreeRule extends Model
{
    use HasFactory;
    protected $table = 'oc_free_rule';
    public $timestamps = false;
    protected $primaryKey = 'id_rule';
}
