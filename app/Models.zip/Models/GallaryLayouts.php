<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class GallaryLayouts extends Model
{
    public $table = "oc_gallary_layouts";
    protected $primaryKey = 'gallary_id';
}
