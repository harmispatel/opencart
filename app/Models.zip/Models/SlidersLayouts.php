<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class SlidersLayouts extends Model
{
    public $table = "oc_sliders_layouts";
    protected $primaryKey = 'popular_food_id';
}
