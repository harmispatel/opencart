<title>404</title>
<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<!------ Include the above in your HEAD tag ---------->

<div class="container">
    <div class="row justify-content-center h-100">
        <div class="col-md-12 text-center text-danger m-auto">
            <h1 style="font-size: 150px;">404 !</h1>
            <p>The page you are looking for was not found.</p>
        </div>
    </div>
</div>
