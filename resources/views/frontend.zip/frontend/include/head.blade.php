<meta charset="utf-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1"/>
<title>Star Kebab & Pizza</title>
<!--Css Files-->
<link href="https://fonts.googleapis.com/css2?family=Raleway:wght@400;700;800&amp;display=swap" rel="stylesheet"/>
<!-- <link rel="stylesheet" href="{assets/plugins/bootstrap/dist/css/bootstrap.min.css"}/>
<link rel="stylesheet" href="{assets/plugins/eonasdan-bootstrap-datetimepicker/build/css/bootstrap-datetimepicker.min.css"}/>
<link rel="stylesheet" href="{assets/plugins/fontawesome/css/all.min.css"}/>
<link rel="stylesheet" href="{assets/plugins/swiper-js/swiper-bundle.min.css"}/>
<link rel="stylesheet" href="{assets/plugins/ui/dist/fancybox.css"}/>
<link rel="stylesheet" href="{assets/plugins/animate.css/animate.min.css"}/>
<link rel="stylesheet" href="{assets/plugins/select2/dist/css/select2.min.css"}/>
<link rel="stylesheet" href="{assets/css/app.css"}/>
<link rel="stylesheet" href="{assets/css/responsive.css"}/> -->

<link rel="stylesheet" href="{!! asset('public/assets/plugins/bootstrap/dist/css/bootstrap.min.css') !!}">
<link rel="stylesheet" href="{!! asset('public/assets/plugins/eonasdan-bootstrap-datetimepicker/build/css/bootstrap-datetimepicker.min.css') !!}">
<link rel="stylesheet" href="{!! asset('public/assets/plugins/fontawesome/css/all.min.css') !!}">
<link rel="stylesheet" href="{!! asset('public/assets/plugins/swiper-js/swiper-bundle.min.css') !!}">
<link rel="stylesheet" href="{!! asset('public/assets/plugins/ui/dist/fancybox.css') !!}">
<link rel="stylesheet" href="{!! asset('public/assets/plugins/animate.css/animate.min.css') !!}">
<link rel="stylesheet" href="{!! asset('public/assets/select2/dist/css/select2.min.css') !!}">
<link rel="stylesheet" href="{!! asset('public/assets/select2/dist/css/select2.min.css') !!}">
<link rel="stylesheet" href="{!! asset('public/assets/css/app.css') !!}">
<link rel="stylesheet" href="{!! asset('public/assets/css/responsive.css') !!}">
