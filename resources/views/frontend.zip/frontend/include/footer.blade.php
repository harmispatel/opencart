<footer class="footer wow animate__fadeInUp" data-wow-duration="1s">
      <div class="container info-group wow animate__fadeInUp" data-wow-duration="1s">
        <div class="row">
          <div class="col-12 col-sm-12 col-md-4 input-group-item"><strong class="title top-divider-red">Our Address</strong>
            <p>Lorem Ipsum Dolor Sit Amet <br>Consensus Feel Free</p>
          </div>
          <div class="col-12 col-sm-12 col-md-4 input-group-item"><strong class="title top-divider-green">Contact Info</strong><a href="mailto:mail@mail.com">mail@mail.com</a><a href="tel:0850 221 22 11">0850 221 22 11</a></div>
          <div class="col-12 col-sm-12 col-md-4 input-group-item"><strong class="title top-divider-orange">Our Reservation</strong>
            <p>You can make a reservation online by <br> clicking on find table link.</p>
          </div>
        </div>
      </div><a class="f-logo" href=""><img class="img-fluid" src="./assets/img/logo/f-logo.svg"/></a>
      <ul class="social-links">
        <li><a class="fab fa-facebook" href="#" target="_blank"></a></li>
        <li><a class="fab fa-twitter" href="#" target="_blank"></a></li>
        <li><a class="fab fa-pinterest-p" href="#" target="_blank"></a></li>
        <li><a class="fab fa-instagram" href="#" target="_blank"></a></li>
      </ul>
      <div class="copyright">
        <p>Copyright © 2021 Star Kebab Tenterden</p>
      </div>
    </footer>