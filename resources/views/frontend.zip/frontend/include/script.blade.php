<!--Js Files-->
    <script type="text/javascript" src="{{ asset('public/assets/plugins/jquery/dist/jquery.min.js') }}"></script>
    <script type="text/javascript" src="{{ asset('public/assets/plugins/moment/min/moment.min.js') }}"></script>
    <script type="text/javascript" src="{{ asset('public/assets/plugins/moment/min/locales.min.js') }}"></script>
    <script type="text/javascript" src="{{ asset('public/assets/plugins/bootstrap/dist/js/bootstrap.min.js') }}"></script>
    <script type="text/javascript" src="{{ asset('public/assets/plugins/eonasdan-bootstrap-datetimepicker/build/js/bootstrap-datetimepicker.min.js') }}"></script>
    <script type="text/javascript" src="{{ asset('public/assets/plugins/wow/dist/wow.min.js') }}"></script>
    <script type="text/javascript" src="{{ asset('public/assets/plugins/swiper-js/swiper-bundle.min.js') }}"></script>
    <script type="text/javascript" src="{{ asset('public/assets/plugins/ui/dist/fancybox.umd.js') }}"></script>
    <script type="text/javascript" src="{{ asset('public/assets/plugins/select2/dist/js/select2.min.js') }}"></script>
    <script type="text/javascript" src="{{ asset('public/assets/plugins/select2/dist/js/i18n/tr.js') }}"></script>
    <script type="text/javascript" src="{{ asset('public/assets/js/app.js') }}"></script>
