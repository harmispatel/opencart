@extends('frontend.layout.layout')
@section('content')

   <div class="restaurant-status open wow animate__bounceInDown" data-wow-duration="1s"><img class="img-fluid" src="{{ asset('public/assets/img/icon/open.svg') }}"/><img class="img-fluid" src="./assets/img/icon/closed.svg"/></div>
    <section class="home-slide">
      <div class="swiper">
        <div class="swiper-wrapper">
          <div class="swiper-slide"><strong class="title text-uppercase">welcome to</strong><strong class="sub-title text-capitalize">kebab & pizza</strong><img class="img-fluid" style="background-image: url({{ asset('public/assets/demo-data/home-slider.jpg')}})"/></div>
          <div class="swiper-slide"><strong class="title text-uppercase">welcome to</strong><strong class="sub-title text-capitalize">star kebab & pizza</strong><img class="img-fluid" style="background-image: url({{ asset('public/assets/demo-data/home-slider.jpg')}})"/></div>
        </div>
        <div class="swiper-button-next"><i class="fas fa-arrow-right"></i></div>
        <div class="swiper-button-prev"><i class="fas fa-arrow-left"></i></div>
      </div>
      <div class="order-online wow animate__fadeInUp" data-wow-duration="1s"><strong class="title text-uppercase">order online</strong>
        <input class="form-control" placeholder="Eg. AA11AA"/>
        <p>Please enter your postcode to view our<br> menu and place an order</p>
        <div class="btn__group"><a class="btn btn-green text-uppercase">collection</a><a class="btn btn-red text-uppercase">delivery</a></div>
      </div>
    </section>
    <section class="welcome pt-110 pb-110">
      <div class="container">
         <div class="row">
            <div class="col-sm-12 col-md-6 wow animate__fadeInLeft" data-wow-duration="1s">
                <h3 class="section-title color-green">Welcome to <br> Star Kebab & Pizza</h3>
                <p>Duis aute irure dolor in reprehenderit in voluptate velit esse cillum <br>dolore eu fugiat nulla pariatur.</p>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, <br>sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea <br>commodo consequat. <br>Duis aute irure dolor in reprehenderit in voluptate velit esse dolore eu fugiat nulla pariatur.</p><a class="btn btn-green text-uppercase" href="">read more</a>
            </div>
            <div class="col-sm-12 col-md-6 wow animate__fadeInRight" data-wow-duration="1s">
               <div class="img-box"><img class="img-fluid" src="{{ asset('public/assets/demo-data/welcome-bg.jpg')}}"/></div>
            </div>
         </div>
      </div>
    </section>
    <section class="categories pt-110 pb-110">
      <div class="container pt-110 pb-110 wow animate__fadeInUp" data-wow-duration="1s">
        <h3 class="section-title color-red">Best Categories</h3>
        <p class="text">Duis aute irure dolor in reprehenderit in voluptate velit esse cillum <br> dolore eu fugiat nulla pariatur.</p>
        <div class="categories-swiper">
          <div class="swiper-button-next"><i class="fas fa-arrow-right"></i></div>
          <div class="swiper-button-prev"><i class="fas fa-arrow-left"></i></div>
          <div class="swiper">
            <div class="swiper-wrapper"><a class="swiper-slide" href="#">
                <div class="img"><img class="img-fluid" src="{{ asset('public/assets/demo-data/best-categories/0.jpg')}}"/></div><strong>Breakfast Chef 0</strong>
                <p>Lorem ipsum dolor sit amet, consectetur 0</p></a><a class="swiper-slide" href="#">
                <div class="img"><img class="img-fluid" src="{{ asset('public/assets/demo-data/best-categories/1.jpg')}}"/></div><strong>Breakfast Chef 1</strong>
                <p>Lorem ipsum dolor sit amet, consectetur 1</p></a><a class="swiper-slide" href="#">
                <div class="img"><img class="img-fluid" src="{{ asset('public/assets/demo-data/best-categories/2.jpg')}}"/></div><strong>Breakfast Chef 2</strong>
                <p>Lorem ipsum dolor sit amet, consectetur 2</p></a><a class="swiper-slide" href="#">
                <div class="img"><img class="img-fluid" src="{{ asset('public/assets/demo-data/best-categories/3.jpg')}}"/></div><strong>Breakfast Chef 3</strong>
                <p>Lorem ipsum dolor sit amet, consectetur 3</p></a><a class="swiper-slide" href="#">
                <div class="img"><img class="img-fluid" src="{{ asset('public/assets/demo-data/best-categories/4.jpg')}}"/></div><strong>Breakfast Chef 4</strong>
                <p>Lorem ipsum dolor sit amet, consectetur 4</p></a><a class="swiper-slide" href="#">
                <div class="img"><img class="img-fluid" src="{{ asset('public/assets/demo-data/best-categories/0.jpg')}}"/></div><strong>Breakfast Chef 5</strong>
                <p>Lorem ipsum dolor sit amet, consectetur 5</p></a><a class="swiper-slide" href="#">
                <div class="img"><img class="img-fluid" src="{{ asset('public/assets/demo-data/best-categories/1.jpg')}}"/></div><strong>Breakfast Chef 6</strong>
                <p>Lorem ipsum dolor sit amet, consectetur 6</p></a><a class="swiper-slide" href="#">
                <div class="img"><img class="img-fluid" src="{{ asset('public/assets/demo-data/best-categories/2.jpg')}}"/></div><strong>Breakfast Chef 7</strong>
                <p>Lorem ipsum dolor sit amet, consectetur 7</p></a><a class="swiper-slide" href="#">
                <div class="img"><img class="img-fluid" src="{{ asset('public/assets/demo-data/best-categories/3.jpg')}}"/></div><strong>Breakfast Chef 8</strong>
                <p>Lorem ipsum dolor sit amet, consectetur 8</p></a><a class="swiper-slide" href="#">
                <div class="img"><img class="img-fluid" src="{{ asset('public/assets/demo-data/best-categories/4.jpg')}}"/></div><strong>Breakfast Chef 9</strong>
                <p>Lorem ipsum dolor sit amet, consectetur 9</p></a><a class="swiper-slide" href="#">
                <div class="img"><img class="img-fluid" src="{{ asset('public/assets/demo-data/best-categories/0.jpg')}}"/></div><strong>Breakfast Chef 10</strong>
                <p>Lorem ipsum dolor sit amet, consectetur 10</p></a><a class="swiper-slide" href="#">
                <div class="img"><img class="img-fluid" src="{{ asset('public/assets/demo-data/best-categories/1.jpg')}}"/></div><strong>Breakfast Chef 11</strong>
                <p>Lorem ipsum dolor sit amet, consectetur 11</p></a><a class="swiper-slide" href="#">
                <div class="img"><img class="img-fluid" src="{{ asset('public/assets/demo-data/best-categories/2.jpg')}}"/></div><strong>Breakfast Chef 12</strong>
                <p>Lorem ipsum dolor sit amet, consectetur 12</p></a><a class="swiper-slide" href="#">
                <div class="img"><img class="img-fluid" src="{{ asset('public/assets/demo-data/best-categories/3.jpg')}}"/></div><strong>Breakfast Chef 13</strong>
                <p>Lorem ipsum dolor sit amet, consectetur 13</p></a><a class="swiper-slide" href="#">
                <div class="img"><img class="img-fluid" src="{{ asset('public/assets/demo-data/best-categories/4.jpg')}}"/></div><strong>Breakfast Chef 14</strong>
                <p>Lorem ipsum dolor sit amet, consectetur 14</p></a>
            </div>
          </div>
        </div>
      </div>
    </section>
    <section class="popular-foods">
      <div class="container pt-110 pb-110 wow animate__fadeInUp" data-wow-duration="1s">
        <h3 class="section-title color-green">Popular Foods</h3>
        <p class="text">Duis aute irure dolor in reprehenderit in voluptate velit esse cillum <br> dolore eu fugiat nulla pariatur.</p>
        <div class="popular-foods-swiper">
          <div class="swiper">
            <div class="swiper-wrapper"><a class="swiper-slide" href="#">
                <div class="box">
                  <div class="img"><img class="img-fluid" src="{{ asset('public/assets/demo-data/popular-foods/1.jpg')}}"/></div><strong>Breakfast Chef 0</strong>
                  <p>Lorem ipsum dolor sit amet, consectetur 0</p>
                </div></a><a class="swiper-slide" href="#">
                <div class="box">
                  <div class="img"><img class="img-fluid" src="{{ asset('public/assets/demo-data/popular-foods/2.jpg')}}"/></div><strong>Breakfast Chef 1</strong>
                  <p>Lorem ipsum dolor sit amet, consectetur 1</p>
                </div></a><a class="swiper-slide" href="#">
                <div class="box">
                  <div class="img"><img class="img-fluid" src="{{ asset('public/assets/demo-data/popular-foods/3.jpg')}}"/></div><strong>Breakfast Chef 2</strong>
                  <p>Lorem ipsum dolor sit amet, consectetur 2</p>
                </div></a><a class="swiper-slide" href="#">
                <div class="box">
                  <div class="img"><img class="img-fluid" src="{{ asset('public/assets/demo-data/popular-foods/4.jpg')}}"/></div><strong>Breakfast Chef 3</strong>
                  <p>Lorem ipsum dolor sit amet, consectetur 3</p>
                </div></a><a class="swiper-slide" href="#">
                <div class="box">
                  <div class="img"><img class="img-fluid" src="{{ asset('public/assets/demo-data/popular-foods/5.jpg')}}"/></div><strong>Breakfast Chef 4</strong>
                  <p>Lorem ipsum dolor sit amet, consectetur 4</p>
                </div></a><a class="swiper-slide" href="#">
                <div class="box">
                  <div class="img"><img class="img-fluid" src="{{ asset('public/assets/demo-data/popular-foods/6.jpg')}}"/></div><strong>Breakfast Chef 5</strong>
                  <p>Lorem ipsum dolor sit amet, consectetur 5</p>
                </div></a><a class="swiper-slide" href="#">
                <div class="box">
                  <div class="img"><img class="img-fluid" src="{{ asset('public/assets/demo-data/popular-foods/7.jpg')}}"/></div><strong>Breakfast Chef 6</strong>
                  <p>Lorem ipsum dolor sit amet, consectetur 6</p>
                </div></a><a class="swiper-slide" href="#">
                <div class="box">
                  <div class="img"><img class="img-fluid" src="{{ asset('public/assets/demo-data/popular-foods/8.jpg')}}"/></div><strong>Breakfast Chef 7</strong>
                  <p>Lorem ipsum dolor sit amet, consectetur 7</p>
                </div></a><a class="swiper-slide" href="#">
                <div class="box">
                  <div class="img"><img class="img-fluid" src="{{ asset('public/assets/demo-data/popular-foods/9.jpg')}}"/></div><strong>Breakfast Chef 8</strong>
                  <p>Lorem ipsum dolor sit amet, consectetur 8</p>
                </div></a><a class="swiper-slide" href="#">
                <div class="box">
                  <div class="img"><img class="img-fluid" src="{{ asset('public/assets/demo-data/popular-foods/10.jpg')}}"/></div><strong>Breakfast Chef 9</strong>
                  <p>Lorem ipsum dolor sit amet, consectetur 9</p>
                </div></a><a class="swiper-slide" href="#">
                <div class="box">
                  <div class="img"><img class="img-fluid" src="{{ asset('public/assets/demo-data/popular-foods/1.jpg')}}"/></div><strong>Breakfast Chef 10</strong>
                  <p>Lorem ipsum dolor sit amet, consectetur 10</p>
                </div></a><a class="swiper-slide" href="#">
                <div class="box">
                  <div class="img"><img class="img-fluid" src="{{ asset('public/assets/demo-data/popular-foods/2.jpg')}}"/></div><strong>Breakfast Chef 11</strong>
                  <p>Lorem ipsum dolor sit amet, consectetur 11</p>
                </div></a><a class="swiper-slide" href="#">
                <div class="box">
                  <div class="img"><img class="img-fluid" src="{{ asset('public/assets/demo-data/popular-foods/3.jpg')}}"/></div><strong>Breakfast Chef 12</strong>
                  <p>Lorem ipsum dolor sit amet, consectetur 12</p>
                </div></a><a class="swiper-slide" href="#">
                <div class="box">
                  <div class="img"><img class="img-fluid" src="{{ asset('public/assets/demo-data/popular-foods/4.jpg')}}"/></div><strong>Breakfast Chef 13</strong>
                  <p>Lorem ipsum dolor sit amet, consectetur 13</p>
                </div></a><a class="swiper-slide" href="#">
                <div class="box">
                  <div class="img"><img class="img-fluid" src="{{ asset('public/assets/demo-data/popular-foods/5.jpg')}}"/></div><strong>Breakfast Chef 14</strong>
                  <p>Lorem ipsum dolor sit amet, consectetur 14</p>
                </div></a><a class="swiper-slide" href="#">
                <div class="box">
                  <div class="img"><img class="img-fluid" src="{{ asset('public/assets/demo-data/popular-foods/6.jpg')}}"/></div><strong>Breakfast Chef 15</strong>
                  <p>Lorem ipsum dolor sit amet, consectetur 15</p>
                </div></a><a class="swiper-slide" href="#">
                <div class="box">
                  <div class="img"><img class="img-fluid" src="{{ asset('public/assets/demo-data/popular-foods/7.jpg')}}"/></div><strong>Breakfast Chef 16</strong>
                  <p>Lorem ipsum dolor sit amet, consectetur 16</p>
                </div></a><a class="swiper-slide" href="#">
                <div class="box">
                  <div class="img"><img class="img-fluid" src="{{ asset('public/assets/demo-data/popular-foods/8.jpg')}}"/></div><strong>Breakfast Chef 17</strong>
                  <p>Lorem ipsum dolor sit amet, consectetur 17</p>
                </div></a><a class="swiper-slide" href="#">
                <div class="box">
                  <div class="img"><img class="img-fluid" src="{{ asset('public/assets/demo-data/popular-foods/9.jpg')}}"/></div><strong>Breakfast Chef 18</strong>
                  <p>Lorem ipsum dolor sit amet, consectetur 18</p>
                </div></a><a class="swiper-slide" href="#">
                <div class="box">
                  <div class="img"><img class="img-fluid" src="{{ asset('public/assets/demo-data/popular-foods/10.jpg')}}"/></div><strong>Breakfast Chef 19</strong>
                  <p>Lorem ipsum dolor sit amet, consectetur 19</p>
                </div></a><a class="swiper-slide" href="#">
                <div class="box">
                  <div class="img"><img class="img-fluid" src="{{ asset('public/assets/demo-data/popular-foods/1.jpg')}}"/></div><strong>Breakfast Chef 20</strong>
                  <p>Lorem ipsum dolor sit amet, consectetur 20</p>
                </div></a><a class="swiper-slide" href="#">
                <div class="box">
                  <div class="img"><img class="img-fluid" src="{{ asset('public/assets/demo-data/popular-foods/2.jpg')}}"/></div><strong>Breakfast Chef 21</strong>
                  <p>Lorem ipsum dolor sit amet, consectetur 21</p>
                </div></a><a class="swiper-slide" href="#">
                <div class="box">
                  <div class="img"><img class="img-fluid" src="{{ asset('public/assets/demo-data/popular-foods/3.jpg')}}"/></div><strong>Breakfast Chef 22</strong>
                  <p>Lorem ipsum dolor sit amet, consectetur 22</p>
                </div></a><a class="swiper-slide" href="#">
                <div class="box">
                  <div class="img"><img class="img-fluid" src="{{ asset('public/assets/demo-data/popular-foods/4.jpg')}}"/></div><strong>Breakfast Chef 23</strong>
                  <p>Lorem ipsum dolor sit amet, consectetur 23</p>
                </div></a><a class="swiper-slide" href="#">
                <div class="box">
                  <div class="img"><img class="img-fluid" src="{{ asset('public/assets/demo-data/popular-foods/5.jpg')}}"/></div><strong>Breakfast Chef 24</strong>
                  <p>Lorem ipsum dolor sit amet, consectetur 24</p>
                </div></a><a class="swiper-slide" href="#">
                <div class="box">
                  <div class="img"><img class="img-fluid" src="{{ asset('public/assets/demo-data/popular-foods/6.jpg')}}"/></div><strong>Breakfast Chef 25</strong>
                  <p>Lorem ipsum dolor sit amet, consectetur 25</p>
                </div></a><a class="swiper-slide" href="#">
                <div class="box">
                  <div class="img"><img class="img-fluid" src="{{ asset('public/assets/demo-data/popular-foods/7.jpg')}}"/></div><strong>Breakfast Chef 26</strong>
                  <p>Lorem ipsum dolor sit amet, consectetur 26</p>
                </div></a><a class="swiper-slide" href="#">
                <div class="box">
                  <div class="img"><img class="img-fluid" src="{{ asset('public/assets/demo-data/popular-foods/8.jpg')}}"/></div><strong>Breakfast Chef 27</strong>
                  <p>Lorem ipsum dolor sit amet, consectetur 27</p>
                </div></a><a class="swiper-slide" href="#">
                <div class="box">
                  <div class="img"><img class="img-fluid" src="{{ asset('public/assets/demo-data/popular-foods/9.jpg')}}"/></div><strong>Breakfast Chef 28</strong>
                  <p>Lorem ipsum dolor sit amet, consectetur 28</p>
                </div></a><a class="swiper-slide" href="#">
                <div class="box">
                  <div class="img"><img class="img-fluid" src="{{ asset('public/assets/demo-data/popular-foods/10.jpg')}}"/></div><strong>Breakfast Chef 29</strong>
                  <p>Lorem ipsum dolor sit amet, consectetur 29</p>
                </div></a>
            </div>
          </div>
          <div class="swiper-pagination"></div>
        </div>
      </div>
    </section>
    <section class="user-comments pt-110 pb-110">
      <div class="container pt-110 pb-110 wow animate__fadeInUp" data-wow-duration="1s">
        <h3 class="section-title color-red">Recent Web Reviews</h3>
        <p class="text">Duis aute irure dolor in reprehenderit in voluptate velit esse cillum <br> dolore eu fugiat nulla pariatur.</p>
        <div class="user-comments-swiper">
          <div class="swiper">
            <div class="swiper-wrapper">
              <div class="swiper-slide">
                <div class="message-text"><strong>THAT’S AN AWESOME RESTAURANT & FOOD 0</strong>
                  <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, <br>sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad <br>minim veniam, quis nostrud exercitation 0</p>
                </div>
                <div class="message-info"><strong>Selçuk Aker</strong><span>UX Designer</span></div>
              </div>
              <div class="swiper-slide">
                <div class="message-text"><strong>THAT’S AN AWESOME RESTAURANT & FOOD 1</strong>
                  <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, <br>sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad <br>minim veniam, quis nostrud exercitation 1</p>
                </div>
                <div class="message-info"><strong>Selçuk Aker</strong><span>UX Designer</span></div>
              </div>
              <div class="swiper-slide">
                <div class="message-text"><strong>THAT’S AN AWESOME RESTAURANT & FOOD 2</strong>
                  <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, <br>sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad <br>minim veniam, quis nostrud exercitation 2</p>
                </div>
                <div class="message-info"><strong>Selçuk Aker</strong><span>UX Designer</span></div>
              </div>
            </div>
          </div>
          <div class="swiper-pagination"></div>
        </div>
      </div>
    </section>
    <section class="reservation pt-110 pb-110">
      <div class="container wow animate__fadeInUp" data-wow-duration="1s">
        <h3 class="section-title color-green divider-white text-capitalize">make a reservation</h3>
        <p class="text">Duis aute irure dolor in reprehenderit in voluptate velit esse cillum <br> dolore eu fugiat nulla pariatur.</p>
        <form class="row" method="" action="">
          <div class="col-12 col-sm-6 col-md-6 col-lg-4 mb-4">
            <input class="form-control" placeholder="Full Name" type="text"/>
          </div>
          <div class="col-12 col-sm-6 col-md-6 col-lg-4 mb-4">
            <input class="form-control" placeholder="Phone Number" type="text"/>
          </div>
          <div class="col-12 col-sm-6 col-md-6 col-lg-4 mb-4">
            <div class="icon"><i class="fas fa-chevron-down"></i>
              <select class="form-control select2">
                <option value="" selected="selected">Person</option>
                <option value="1">1</option>
                <option value="2">2</option>
                <option value="3">3</option>
                <option value="4">4</option>
                <option value="5">5</option>
                <option value="6">6</option>
                <option value="7">7</option>
                <option value="8">8</option>
                <option value="9">9</option>
              </select>
            </div>
          </div>
          <div class="col-12 col-sm-6 col-md-6 col-lg-4 mb-4">
            <div class="icon"><i class="fas fa-chevron-down"></i>
              <input class="form-control icon" placeholder="Date" id="date" type="text"/>
            </div>
          </div>
          <div class="col-12 col-sm-6 col-md-6 col-lg-4 mb-4">
            <div class="icon"><i class="fas fa-chevron-down"></i>
              <input class="form-control icon" placeholder="Time" id="time" type="text"/>
            </div>
          </div>
          <div class="col-12 col-sm-6 col-md-6 col-lg-4 mb-4">
            <button class="btn btn-green text-capitalize">make reservation now<i class="fas fa-arrow-right"></i></button>
          </div>
        </form>
      </div>
    </section>
    <section class="photo-gallery pt-110 pb-110">
      <div class="container wow animate__fadeInUp" data-wow-duration="1s">
        <h3 class="section-title color-green divider-white text-capitalize">photo gallery</h3>
        <p class="text">Duis aute irure dolor in reprehenderit in voluptate velit esse cillum <br> dolore eu fugiat nulla pariatur.</p>
      </div>
      <div class="container-fluid wow animate__fadeInUp" data-wow-duration="1s">
        <div class="row">
          <div class="col-sm-6 col-md-4 col-lg-3 col-xl-2">
            <div class="box"><a class="fas fa-search-plus" href="{{ asset('public/assets/demo-data/photo-gallery/1.jpg')}}" data-fancybox="photoGallery"></a><img class="img-fluid" src="{{ asset('public/assets/demo-data/photo-gallery/1.jpg')}}"/></div>
          </div>
          <div class="col-sm-6 col-md-4 col-lg-3 col-xl-2">
            <div class="box"><a class="fas fa-search-plus" href="{{ asset('public/assets/demo-data/photo-gallery/2.jpg')}}" data-fancybox="photoGallery"></a><img class="img-fluid" src="{{ asset('public/assets/demo-data/photo-gallery/2.jpg')}}"/></div>
          </div>
          <div class="col-sm-6 col-md-4 col-lg-3 col-xl-2">
            <div class="box"><a class="fas fa-search-plus" href="{{ asset('public/assets/demo-data/photo-gallery/3.jpg')}}" data-fancybox="photoGallery"></a><img class="img-fluid" src="{{ asset('public/assets/demo-data/photo-gallery/3.jpg')}}"/></div>
          </div>
          <div class="col-sm-6 col-md-4 col-lg-3 col-xl-2">
            <div class="box"><a class="fas fa-search-plus" href="{{ asset('public/assets/demo-data/photo-gallery/4.jpg')}}" data-fancybox="photoGallery"></a><img class="img-fluid" src="{{ asset('public/assets/demo-data/photo-gallery/4.jpg')}}"/></div>
          </div>
          <div class="col-sm-6 col-md-4 col-lg-3 col-xl-2">
            <div class="box"><a class="fas fa-search-plus" href="{{ asset('public/assets/demo-data/photo-gallery/5.jpg')}}" data-fancybox="photoGallery"></a><img class="img-fluid" src="{{ asset('public/assets/demo-data/photo-gallery/5.jpg')}}"/></div>
          </div>
          <div class="col-sm-6 col-md-4 col-lg-3 col-xl-2">
            <div class="box"><a class="fas fa-search-plus" href="{{ asset('public/assets/demo-data/photo-gallery/6.jpg')}}" data-fancybox="photoGallery"></a><img class="img-fluid" src="{{ asset('public/assets/demo-data/photo-gallery/6.jpg')}}"/></div>
          </div>
          <div class="col-sm-6 col-md-4 col-lg-3 col-xl-2">
            <div class="box"><a class="fas fa-search-plus" href="{{ asset('public/assets/demo-data/photo-gallery/7.jpg')}}" data-fancybox="photoGallery"></a><img class="img-fluid" src="{{ asset('public/assets/demo-data/photo-gallery/7.jpg')}}"/></div>
          </div>
          <div class="col-sm-6 col-md-4 col-lg-3 col-xl-2">
            <div class="box"><a class="fas fa-search-plus" href="{{ asset('public/assets/demo-data/photo-gallery/8.jpg')}}" data-fancybox="photoGallery"></a><img class="img-fluid" src="{{ asset('public/assets/demo-data/photo-gallery/8.jpg')}}"/></div>
          </div>
          <div class="col-sm-6 col-md-4 col-lg-3 col-xl-2">
            <div class="box"><a class="fas fa-search-plus" href="{{ asset('public/assets/demo-data/photo-gallery/9.jpg')}}" data-fancybox="photoGallery"></a><img class="img-fluid" src="{{ asset('public/assets/demo-data/photo-gallery/9.jpg')}}"/></div>
          </div>
          <div class="col-sm-6 col-md-4 col-lg-3 col-xl-2">
            <div class="box"><a class="fas fa-search-plus" href="{{ asset('public/assets/demo-data/photo-gallery/10.jpg')}}" data-fancybox="photoGallery"></a><img class="img-fluid" src="{{ asset('public/assets/demo-data/photo-gallery/10.jpg')}}"/></div>
          </div>
          <div class="col-sm-6 col-md-4 col-lg-3 col-xl-2">
            <div class="box"><a class="fas fa-search-plus" href="{{ asset('public/assets/demo-data/photo-gallery/11.jpg')}}" data-fancybox="photoGallery"></a><img class="img-fluid" src="{{ asset('public/assets/demo-data/photo-gallery/11.jpg')}}"/></div>
          </div>
          <div class="col-sm-6 col-md-4 col-lg-3 col-xl-2">
            <div class="box"><a class="fas fa-search-plus" href="{{ asset('public/assets/demo-data/photo-gallery/12.jpg')}}" data-fancybox="photoGallery"></a><img class="img-fluid" src="{{ asset('public/assets/demo-data/photo-gallery/12.jpg')}}"/></div>
          </div>
        </div>
      </div>
    </section>
    <section class="opening-hours pt-110 wow animate__fadeInUp" data-wow-duration="1s" style="background-image: url({{ asset('public/assets/img/bg/opening-hours-bg.jpg')}})">
      <div class="container text-center">
        <h3 class="title">Visit us</h3>
        <h3 class="sub-title">Opening Hours</h3><img class="img-fluid" src="{{ asset('public/assets/img/icon/opening-hours.svg"/>
        <p>Sunday to Tuesday 09.00 – 23:00  |  Sunday 08:00 – 23:00</p>
      </div>
    </section>

@stop
